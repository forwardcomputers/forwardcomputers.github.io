import abc

from trashcli.fs import IsSymLink, ContentsOf, EntriesIfDirExists, PathExists, \
    IsStickyDir, HasStickyBit


class FileSystemReaderForListCmd(
    IsStickyDir,
    HasStickyBit,
    IsSymLink,
    ContentsOf,
    EntriesIfDirExists,
    PathExists,
    metaclass=abc.ABCMeta
):
    pass
