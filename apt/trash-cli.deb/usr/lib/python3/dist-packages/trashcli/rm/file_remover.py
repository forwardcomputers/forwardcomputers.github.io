from trashcli.fs import FsMethods


class FileRemover:
    remove_file2 = FsMethods().remove_file2
    remove_file_if_exists = FsMethods().remove_file_if_exists
