def parse_reply(reply):
    return reply[0:1].lower() == 'y'
