from abc import ABCMeta, abstractmethod

from trashcli.restore.output_event import OutputEvent


class Output(metaclass=ABCMeta):
    @abstractmethod
    def quit(self):
        raise NotImplementedError

    @abstractmethod
    def die(self, msg):
        raise NotImplementedError

    @abstractmethod
    def println(self, msg):
        raise NotImplementedError

    @abstractmethod
    def append_event(self,
                     event,  # type: OutputEvent
                     ):
        raise NotImplementedError
