from typing import NamedTuple


class Single(NamedTuple('Single', [
    ('index', int),
])):
    pass
