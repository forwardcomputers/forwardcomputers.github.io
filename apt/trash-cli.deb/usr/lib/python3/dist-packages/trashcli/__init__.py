import os


base_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), ".."))
